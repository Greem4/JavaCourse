package edu.javacourse.serial;

public interface Processor {

    String process(String code, String name);
}
