package edu.javacourse.xml.example.entity;

import java.util.List;

public class Person {
    private String lastName;
    private String firstName;
    private List<Phone> phones;

}
