package edu.javacourse.inteface;

public class MyClass2 implements MyInterface2 {
}
