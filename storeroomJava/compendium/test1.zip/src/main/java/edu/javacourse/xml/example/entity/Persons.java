package edu.javacourse.xml.example.entity;

import java.util.List;

public class Persons {

    private List<Person> persons;
}
