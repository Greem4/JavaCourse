package edu.javacourse.instance;

public class SimpleException extends Exception {
    public SimpleException(String message) {
        super(message);
    }

}
